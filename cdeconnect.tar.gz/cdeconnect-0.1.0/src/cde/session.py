import time
import os
from typing import Any, Optional
import requests

from .config import Config
from .auth import CDEChannelBuilder
from pyspark.sql import SparkSession
from pyspark.sql.connect.session import SparkSession as RemoteSparkSession
import logging


class classproperty(property):
    def __get__(self, instance: Any, owner: Any = None) -> "CDESparkConnectSession.Builder":
        # The "type: ignore" below silences the following error from mypy:
        # error: Argument 1 to "classmethod" has incompatible
        # type "Optional[Callable[[Any], Any]]";
        # expected "Callable[..., Any]"  [arg-type]
        return classmethod(self.fget).__get__(None, owner)()  # type: ignore


logger = logging

class CDESparkConnectSession:
    """
    CDESparkConnectSession object for CDE Connect.
    Create a new Pyspark session which connects to a remote Spark cluster and executes specified
    DataFrame APIs.

    Examples
    --------
    >>> spark = CDESparkConnectSession.builder.get()
    >>> df = spark.range(10)
    >>> print(df)
    """

    class Builder:
        """
        Builder to construct connection parameters.
        An instance of this class can be created using CDESparkConnectSession.builder.
        
        Examples
        --------
        Using parameters
        >>> spark = CDESparkConnectSession.builder.remote(
        >>>     host="sc-example.apps.cloudera.com",
        >>>     sessionName="example-session"
        >>> ).get()
        
        Using builder
        >>> spark = CDESparkConnectSession.builder.host("sc-example.apps.cloudera.com")
        >>>     .sessionName("example-session").get()
        """

        def __init__(self):
            self._host: Optional[str] = None
            self._session_name: Optional[str] = None
            self._headers: dict[str, str] = dict()
            self._config_location = None

        def remote(
            self,
            conn_string: str = None,
            *,
            host: str = None,
            session_name: str = None,
            headers: Optional['dict[str, str]'] = None,
        ) -> "CDESparkConnectSession.Builder":
            """
            Specify connection parameters to connect to the remote CDE
            cluster.

            Args:
            host : str, optional
                The CDE Spark Connect Endpoint Hostname 
            session_name: str, optional
                The name of the session where the CDE connect queries should be executed.
            headers: dict[str, str], optional
                Extra headers to use while initializing Spark Connect.

            Returns:
            CDESparkConnectSession.Builder
                The same instance of this class with the values configured.
            """
            self._conn_string = conn_string
            self.host(host)
            self.session_name(session_name)
            self.headers(headers)
            return self

        def host(self, host: str) -> "CDESparkConnectSession.Builder":
            """
            The CDE spark connect endpoint hostname.
            """
            self._host = host
            return self

        def sessionName(self, session_name: str) -> "CDESparkConnectSession.Builder":
            """
            The session name where the spark connect queries should be executed.
            """
            self._session_name = session_name
            return self

        def headers(self, headers: 'dict[str, str]'):
            """
            Extra Headers to use while initializing Spark Connect.
            """

            if headers:
                self._headers.update(headers)

            return self

        def cdeConfigLocation(self, config_location: str) -> "CDESparkConnectSession.Builder":
            """
            Custom location of the cde config.yaml file
            """
            self._config_location = config_location
            return self

        def profile(self, profile: str):
            """
            TODO: Add support for cde profiles
            """
            self._profile = profile
            return self
        
        def get(self) -> SparkSession:
            """
            Create a new SparkSession that can be used to execute DataFrame APIs on.
            """

            if self._host is not None or self._session_name is not None:
                logger.debug(
                    "Parameters detected during initialization. "
                    + f"host={self._host} | session_name={self._session_name}"
                )

                config = Config(file_location=self._config_location, session_name=self._session_name)
                return self._from_config(config, self._headers)

            logger.debug("Falling back to default")
            return self._from_config(Config(), self._headers)

        @staticmethod
        def _check_session_status(config, session_name):
            token = CDEChannelBuilder.getCDEToken(config=config)
            vc_url = config.get('vcluster-endpoint')
            verify_ssl = not config.get_bool('tls-insecure')
            session_url = "/".join([vc_url, "sessions", session_name])
            for _ in range(15):  # Poll for 5 minutes with a 20-second interval
                try:
                    response = requests.get(session_url, headers={'Authorization': f'Bearer {token}'},
                                            verify=verify_ssl, timeout=10)
                    json_response = response.json()
                    if response.status_code == 200:
                        state = json_response.get("state")
                        if json_response.get("type") == 'spark-connect':
                            if state == 'available':
                                logger.info(f"Success! Session {session_name} is in available state.")
                                return True
                            elif state in ['starting', 'preparing']:
                                print(f"Session {session_name} is in {state} state, Waiting...")
                            else:
                                logger.error(f"Session {session_name} is in {state} state.")
                                return False
                        else:
                            logger.error(f'Unsupported session type {json_response.get("type")} for '
                                         f'session {session_name}, session should be of type spark-connect')
                            return False
                    else:
                        error_message = json_response.get('message')
                        if error_message == "could not get session from storage: session not found":
                            logger.error(f"Can't connect, Session {session_name} not found.")
                            return False
                        else:
                            logger.warning(f"Retrying... , Can't validate session {session_name} due to {error_message}")
                except requests.RequestException as e:
                    logger.warning(f"Error: {e}, Retrying...")
                time.sleep(20)  # Wait for 20 seconds before the next attempt
            logger.error(f"Failed to connect session {session_name}, Please try again.")
            return False

        @staticmethod
        def _from_config(config: Config,
                            headers: "dict[str, str]") -> SparkSession:
            if config.session_name is None and "x-cde-session-name" not in headers:
                raise Exception("Session name is required but was not specified.")

            if "x-cde-session-name" in headers:
                logger.debug("Connecting to CDE Session with name: "
                             f"{headers['x-cde-session-id']}")
            else:
                logger.debug(f"Creating SparkSession from SDK config: {config}")

            session_name = config.session_name if config.session_name is not None else headers['x-cde-session-id']

            # Ensure that the Spark Connect mode is enabled
            os.environ["SPARK_CONNECT_MODE_ENABLED"]="true"
            if CDESparkConnectSession.builder._check_session_status(config, session_name):
                channel_builder = CDEChannelBuilder(config=config, headers=headers)
                return RemoteSparkSession.builder.channelBuilder(channel_builder).getOrCreate()
            else:
                return


    builder: "CDESparkConnectSession.Builder"
    """Create a new instance of :class:CDESparkConnectSession.Builder"""


CDESparkConnectSession.builder = classproperty(lambda cls: cls.Builder())
