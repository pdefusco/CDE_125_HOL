from typing import Any, Callable, List, Optional, Tuple
from urllib.parse import urlparse

import grpc

from .config import Config
from pyspark.sql.connect.client import ChannelBuilder
import requests
from cdpcurl.cdpconfig import load_cdp_config
from cdpcurl.cdpcurl import make_request
import grpc
import re
import json
import jwt
import logging
import os
from datetime import datetime

MAX_MESSAGE_LENGTH = 128 * 1024 * 1024

GRPC_DEFAULT_OPTIONS = [
    ("grpc.max_send_message_length", MAX_MESSAGE_LENGTH),
    ("grpc.max_receive_message_length", MAX_MESSAGE_LENGTH),
]

CDE_SESSION_HEADER = "x-cde-session-name"
TOKEN_EXPIRY_BUFFER_SECONDS = 600
PUC_ENDPOINT_HOST_REGEXP = r'.+(altus|cdp|dev|int|stage).cloudera.com'

TOKEN_CACHE_TTL_SECONDS = 30 * 60  # 30 minutes
_TOKEN_CACHE: "Tuple[str, datetime]" = (None, None)

class CDEChannelBuilder(ChannelBuilder):
    """
    CDEChannelBuilder customizes the pyspark ChannelBuilder to add support for CDE authentication mechanism and session based headers
    """
    def __init__(
        self, config: Config,
        channelOptions: Optional[List[Tuple[str, Any]]] = None,
        headers: Optional['dict[str, str]'] = None,
    ):
        self._config = config
        self.params = {
            CDE_SESSION_HEADER: self._config.session_name
        }

        if headers is not None:
            self.params.update(headers)

        if channelOptions is None:
            self._channel_options = GRPC_DEFAULT_OPTIONS
        else:
            self._channel_options = GRPC_DEFAULT_OPTIONS + channelOptions

    def toChannel(self) -> grpc.Channel:
        """Creates secure channel with an interceptor that takes care of token refresh
        """
        from grpc import _plugin_wrapping  # pylint: disable=cyclic-import

        ssl_creds = grpc.ssl_channel_credentials()
        access_token = CDEChannelBuilder.getCDEToken(self._config)
        plugin_creds = _plugin_wrapping.metadata_plugin_call_credentials(
            CDEAuthMetadataPlugin(access_token, self._config), None
        )
        composite_creds = grpc.composite_channel_credentials(
            ssl_creds, plugin_creds
        )

        token = CDEChannelBuilder.getCDEToken(config=self._config)
        vc_url = self._config.get('vcluster-endpoint')
        info_url = "/".join([vc_url, "info"])
        verify_ssl = not self._config.get_bool('tls-insecure')
        response = requests.get(info_url, headers={'Authorization': f'Bearer {token}'}, verify=verify_ssl, timeout=30)
        info_json_response = response.json()
        spark_connect_url = info_json_response.get("sparkConnectUrl")
        destination = f"{spark_connect_url}:443"
        secure_channel = grpc.secure_channel(destination, composite_creds, self._channel_options)
        return secure_channel

    @staticmethod
    def getCDEToken(config: Config) -> str:
        """
        Utility method to fetch a CDE token from knox based on the configured credentials
        """
        global _TOKEN_CACHE
        # Check if we have a cached token that's still valid
        if _TOKEN_CACHE[0] and _TOKEN_CACHE[1] and \
        (datetime.now() - _TOKEN_CACHE[1]).total_seconds() < TOKEN_CACHE_TTL_SECONDS:
            logging.debug(f"Using cached token for {config.get('vcluster-endpoint')}")
            return _TOKEN_CACHE[0]

        default_headers = {'Content-Type': 'application/json'}
        access_key = config.get('access-key-id')
        private_key = config.get('access-key-secret')
        if not (access_key and private_key):
            credentials_path = config.get('credentials-file')
            if not (credentials_path or os.path.exists(credentials_path)):
                cdp_credentials_path = os.path.expanduser("~") + "/.cdp/credentials"
                cde_credentials_path = os.path.expanduser("~") + "/.cde/credentials"
                if os.path.exists(cdp_credentials_path):
                    credentials_path = cdp_credentials_path
                elif os.path.exists(cde_credentials_path):
                    credentials_path = cde_credentials_path
                else:
                    logging.error("credentials-file is either not configured correctly or is missing.\n"
                                  "credentials-file is automatically checked in ~/.cde and ~/.cdp folder if it is not explicitly set.")
                    raise FileNotFoundError('credentials-file not found')
            credentials_profile =  config.get('credentials-profile') if config.get('credentials-profile') else "default"
            access_key, private_key = load_cdp_config(None, None,
                                        credentials_path,
                                        credentials_profile)
        cluster_id = re.findall(r'cde-[a-zA-Z0-9]*',config.get('vcluster-endpoint'))[0].replace('cde', 'cluster')
        cdp_endpoint = config.get('cdp-endpoint')
        describeUri = cdp_endpoint + '/api/v1/de/describeService'
        payload = { 'clusterId': cluster_id}
        verify_ssl = not config.get_bool('tls-insecure')
        response = make_request("POST",
                            describeUri,
                            default_headers,
                            json.dumps(payload),
                            access_key,
                            private_key,
                            False,
                            verify_ssl)
        describe_response = response.json()
        env_crn = describe_response['service']['environmentCrn']
        
        default_headers = {'Content-Type': 'application/json'}
        iamToken = cdp_endpoint + '/api/v1/iam/generateWorkloadAuthToken'
        payload = {
		"workloadName":   "DE", 
		"environmentCRN": env_crn
	    }
        formFactor = "private"
        if re.match(PUC_ENDPOINT_HOST_REGEXP, cdp_endpoint):
            formFactor = "public"

        if formFactor == "private":
            payload["excludeGroups"] = "true"
        
        response = make_request("POST",
                            iamToken,
                            default_headers,
                            json.dumps(payload),
                            access_key,
                            private_key,
                            False,
                            verify_ssl)
        cdp_token = response.json()['token']
        from urllib.parse import urlparse
        vc_url = urlparse(config.get('vcluster-endpoint'))
        service_host = re.sub(r'^[^\.]+','service', vc_url.hostname)
        auth_uri = vc_url.scheme + '://' + service_host + '/gateway/cdptkn/knoxtoken/api/v1/token'
        default_headers = {'Content-Type': 'application/json'}
        default_headers['Authorization']= f'Bearer {cdp_token}'
        response = requests.request('GET', auth_uri, headers=default_headers,
                                verify=verify_ssl)
        access_token = response.json()['access_token']
        _TOKEN_CACHE = (access_token, datetime.now())
        return access_token

class CDEAuthMetadataPlugin(grpc.AuthMetadataPlugin):
    """A gRPC AuthMetadataPlugin for CDE that inserts the credentials into each request.
        http://www.grpc.io/grpc/python/grpc.html#grpc.AuthMetadataPlugin
    """

    def __init__(self, cached_token: str, config: Config): 
        self.cached_token = cached_token
        self.config = config

    def __call__(self, context: grpc.AuthMetadataContext, callback: grpc.AuthMetadataPluginCallback) -> None:
        """Passes authorization metadata into the given callback.
        """
        if self.cached_token:
            # skip signature verification while decoding as we are only interested in expiry time.
            # knox-server handles token verification.
            decoded_token = jwt.decode(self.cached_token, verify=False, options={'verify_signature': False})
            # get the expiration time from the cached token
            expiration_time = decoded_token['exp']
            expiration_datetime = datetime.fromtimestamp(expiration_time)
            remaining_lifetime = expiration_datetime - datetime.now()
            # refresh cached token if less than the expiry buffer
            if remaining_lifetime.total_seconds() < TOKEN_EXPIRY_BUFFER_SECONDS:
                self.cached_token = CDEChannelBuilder.getCDEToken(self.config)
        else:
            self.cached_token = CDEChannelBuilder.getCDEToken(self.config)
        
        # add cde bearer token to auth metadata
        key, value = "authorization", f"Bearer {self.cached_token}"
        # For some reason grpc plugin expects a minimum of two headers in the callback, so x-cde-client-id is added as a dummy
        callback([(key, value),("x-cde-client-id", "cde-connect")], None)
