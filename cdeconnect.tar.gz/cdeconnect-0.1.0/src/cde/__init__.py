__version__ = "0.1.0"

from .session import *
import logging

logging.getLogger().setLevel(logging.WARNING)
logging.basicConfig(format='%(levelname)s: %(message)s')
