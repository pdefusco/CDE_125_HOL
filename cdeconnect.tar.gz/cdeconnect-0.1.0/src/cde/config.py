from vyper import v, errors
import os
import logging

class Config():
    """
    Configuration class to parse the CDE configs from config.yaml or env variables. The configurations will be same as CDE CLI
    """
    def __init__(self, file_location: str, session_name: str) -> None:
        self.session_name = session_name
        v.set_env_prefix("cde")
        v.automatic_env()
        v.set_env_key_replacer("-", "_")


        if file_location:
            config_file = file_location
        else:
            config_file = os.getenv('CDE_CONFIG')
            
        if config_file:
            v.set_config_file(config_file)
        else:
            v.set_config_name("config")
            v.add_config_path("/etc/cde")
            v.add_config_path(os.getenv("HOME")+"/.cde")
            v.add_config_path(".")

        v.set_config_type("yaml")
        try:
          v.read_in_config()
        except (FileNotFoundError, errors.ConfigFileNotFoundError) as err:
          if not (v.get_string('vcluster-endpoint') and v.get_string('cdp-endpoint')):
              logging.error("CDE configurations should be set via config.yaml file or via environment variables.\n"
                            "vcluster-endpoint and cdp-endpoint configuration values should be set at minimum.\n"
                            "config.yaml file location is searched in /etc/cde, ~/.cde folders.\n"
                            "To use a custom location, set the env variable CDE_CONFIG=/path/to/config.yaml")
              raise err
        
    
    def get(self, config_name) -> str:
        return v.get_string(config_name)
    
    def get_bool(self, config_name) -> bool:
        return v.get_bool(config_name)
    