# Cloudera Data Engineering client for Spark Connect
cde-connect package enables users to connect to a CDE spark connect session directly

## Building and Installing

Local build can be done as below.
```
python setup.py sdist bdist_wheel
pip install dist/cdeconnect-0.1.0.tar.gz
```
Install Pyspark separately based on the CDE PySpark version being used

## Configuring the client

The configurations of CDE CLI are fully inherited. Environment variables and config.yaml is supported. Refer to https://github.infra.cloudera.com/CDH/dex/blob/develop/cmd/cde/README.md#configuring-the-cli

## TLS Configuration

TLS Configuration needs to be done especially for private cloud. Get the certificates for the control plane host, cde virtual cluster, cde base cluster and the spark connect endpoint. Append these certificates into the certifi pem bundle, which is normally located at <python install location or venv>/lib/python3.8/site-packages/certifi/cacert.pem .

For GRPC SSL verification, we need to set the environment variable GRPC_DEFAULT_SSL_ROOTS_FILE_PATH.
```
export GRPC_DEFAULT_SSL_ROOTS_FILE_PATH=venv/lib/python3.8/site-packages/certifi/cacert.pem
```


## Authentication

The cde connect package will automatically obtain the necessary authentication tokens to interact with cde spark connect using an access key.

Refer https://github.infra.cloudera.com/CDH/dex/blob/develop/cmd/cde/README.md#access-key to configure an access key which can be used by cde connect.


## Usage

Once configured, cde connect can directly connect to a specific cde spark connect session using the session name.
```
from cdeconnect import CDESession
spark = CDESession.builder.sessionName('session-1').get()
spark.version
```