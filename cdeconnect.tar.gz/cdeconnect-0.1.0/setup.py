from setuptools import find_packages
from setuptools import setup

setup(
    name='cdeconnect',
    version='0.1.0',
    description='Cloudera Data Engineering Python client package',
    url='https://cloudera.us-west-1.cdp.cloudera.com/',
    author='Cloudera, Inc.',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Intended Audience :: System Administrators',
        'License :: OSI Approved :: GNU Affero General Public License v3',
        'Natural Language :: English',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7'
    ],
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.7",
    install_requires=[
        'configargparse',
        'configparser',
        'pure25519',
        'requests',
        'urllib3[secure]',
        'pyjwt',
        'grpcio-status',
        'grpcio',
        'protobuf',
        'pandas',
        'pyarrow',
        'vyper-config'
    ],
)